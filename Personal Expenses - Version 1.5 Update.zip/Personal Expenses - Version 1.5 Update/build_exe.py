from distutils.core import setup
import py2exe

setup(console=['Personal_Expenses.py'])
