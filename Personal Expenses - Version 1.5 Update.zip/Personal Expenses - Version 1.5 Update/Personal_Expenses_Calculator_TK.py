#########################
#|---------------------|#
#|   In/Outcome Calc   |#
#|=====================|#
#|Author: Beau Saunders|#
#|Version:          1.5|#
#|---------------------|#
#########################

from tkinter import *

def numOfIncome():

    global entNumIncome, windowIncome

    windowMain.destroy()

    windowIncome = Tk()
    windowIncome.geometry("1920x1080")

    background = Canvas(width = 1920, height = 1080).place( x = 0, y = 0)

    labelNumIncome = Label(text="Please enter the number of income you would like to enter (Up to 10 incomes)", font = font1)
    labelNumIncome.pack()
    
    entNumIncome = StringVar()

    entryNumIncome = Entry(textvariable = entNumIncome, font = font1)
    entryNumIncome.pack()

    buttonNumIncome = Button(text="Continue", command = NumIncomeChange, font = font1)
    buttonNumIncome.pack()

def NumIncomeChange():

    NumIncome = entNumIncome.get()
    
    if entNumIncome == 1:

        _1I()

    elif entNumIncome == 2:

        _2I()

    elif entNumIncome == 3:

        _3I()

    elif entNumIncome == 4:

        _4I()

    elif entNumIncome == 5:

        _5I()

    elif entNumIncome == 6:

        _6I()

    elif entNumIncome == 7:

        _7I()

    elif entNumIncome == 8:

        _8I()

    elif entNumIncome == 9:

        _9I()

    elif entNumIncome == 10:

        _10I()

    else:

        print("Something went wrong, please try again.")

        numOfIncome()

##def _1I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##
##    rounded = round(Income1, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##def _2I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##
##    rounded = round(Income1 + Income2, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _3I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##
##    rounded = round(Income1 + Income2 + Income3, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _4I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _5I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##    Income5 = float(input("\nIncome 5 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4 + Income5, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _6I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##    Income5 = float(input("\nIncome 5 = "))
##    Income6 = float(input("\nIncome 6 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4 + Income5 + Income6, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _7I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##    Income5 = float(input("\nIncome 5 = "))
##    Income6 = float(input("\nIncome 6 = "))
##    Income7 = float(input("\nIncome 7 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4 + Income5 + Income6 + Income7, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _8I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##    Income5 = float(input("\nIncome 5 = "))
##    Income6 = float(input("\nIncome 6 = "))
##    Income7 = float(input("\nIncome 7 = "))
##    Income8 = float(input("\nIncome 8 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4 + Income5 + Income6 + Income7 + Income8, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _9I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##    Income5 = float(input("\nIncome 5 = "))
##    Income6 = float(input("\nIncome 6 = "))
##    Income7 = float(input("\nIncome 7 = "))
##    Income8 = float(input("\nIncome 8 = "))
##    Income9 = float(input("\nIncome 9 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4 + Income5 + Income6 + Income7 + Income8 + Income9, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)
##
##
##def _10I():
##
##    print("\nPlease do not type any symbols (e.g. £,$ etc)")
##
##    Income1 = float(input("\nIncome 1 = "))
##    Income2 = float(input("\nIncome 2 = "))
##    Income3 = float(input("\nIncome 3 = "))
##    Income4 = float(input("\nIncome 4 = "))
##    Income5 = float(input("\nIncome 5 = "))
##    Income6 = float(input("\nIncome 6 = "))
##    Income7 = float(input("\nIncome 7 = "))
##    Income8 = float(input("\nIncome 8 = "))
##    Income9 = float(input("\nIncome 9 = "))
##    Income10 = float(input("\nIncome 10 = "))
##
##    rounded = round(Income1 + Income2 + Income3 + Income4 + Income5 + Income6 + Income7 + Income8 + Income9 + Income10, 2)
##
##    totalIncome = str(rounded)
##
##    print("\nYour total income is: £" + totalIncome)

def numOfOutcome():

    numOutcome = int(input("\nPlease enter the number of outcome you would like to enter (Up to 10 outcomes) "))

    if numOutcome == 1:

        _1O()

    elif numOutcome == 2:

        _2O()

    elif numOutcome == 3:

        _3O()

    elif numOutcome == 4:

        _4O()

    elif numOutcome == 5:

        _5O()

    elif numOutcome == 6:

        _6O()

    elif numOutcome == 7:

        _7O()

    elif numOutcome == 8:

        _8O()

    elif numOutcome == 9:

        _9O()

    elif numOutcome == 10:

        _10O()

    else:

        print("Something went wrong, please try again.\n")

        numOfOutcome()

def _1O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")
    
    Outcome1 = float(input("\nOutcome 1 = "))

    rounded = round(Outcome1, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _2O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))

    rounded = round(Outcome1 + Outcome2, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _3O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _4O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _5O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))
    Outcome5 = float(input("\nOutcome 5 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4 + Outcome5, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _6O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))
    Outcome5 = float(input("\nOutcome 5 = "))
    Outcome6 = float(input("\nOutcome 6 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4 + Outcome5 + Outcome6, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _7O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))
    Outcome5 = float(input("\nOutcome 5 = "))
    Outcome6 = float(input("\nOutcome 6 = "))
    Outcome7 = float(input("\nOutcome 7 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4 + Outcome5 + Outcome6 + Outcome7, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _8O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))
    Outcome5 = float(input("\nOutcome 5 = "))
    Outcome6 = float(input("\nOutcome 6 = "))
    Outcome7 = float(input("\nOutcome 7 = "))
    Outcome8 = float(input("\nOutcome 8 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4 + Outcome5 + Outcome6 + Outcome7 + Outcome8, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _9O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))
    Outcome5 = float(input("\nOutcome 5 = "))
    Outcome6 = float(input("\nOutcome 6 = "))
    Outcome7 = float(input("\nOutcome 7 = "))
    Outcome8 = float(input("\nOutcome 8 = "))
    Outcome9 = float(input("\nOutcome 9 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4 + Outcome5 + Outcome6 + Outcome7 + Outcome8 + Outcome9, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def _10O():

    print("\nPlease do not type any symbols (e.g. £,$ etc)")

    Outcome1 = float(input("\nOutcome 1 = "))
    Outcome2 = float(input("\nOutcome 2 = "))
    Outcome3 = float(input("\nOutcome 3 = "))
    Outcome4 = float(input("\nOutcome 4 = "))
    Outcome5 = float(input("\nOutcome 5 = "))
    Outcome6 = float(input("\nOutcome 6 = "))
    Outcome7 = float(input("\nOutcome 7 = "))
    Outcome8 = float(input("\nOutcome 8 = "))
    Outcome9 = float(input("\nOutcome 9 = "))
    Outcome10 = float(input("\nOutcome 10 = "))

    rounded = round(Outcome1 + Outcome2 + Outcome3 + Outcome4 + Outcome5 + Outcome6 + Outcome7 + Outcome8 + Outcome9 + Outcome10, 2)

    totalOutcome = str(rounded)

    print("\nYour total income is: £" + totalOutcome)

def menu():

    global windowMain, font1, font2, font3

    windowMain = Tk()
    windowMain.geometry("1920x1080")

    font1 = ("Freestyle Script", 35, "bold")#Creates a new font.
    font2 = ("Freestyle Script", 18)#Creates a new font.
    font3 = ("Agency FB", 20, "bold")#Creates a new font.

    background = Canvas(width = 1920, height = 1080).place( x = 0, y = 0)

    labelWelcome = Label(text="Welcome to the Personal Expenses Calculator", font = font1)
    labelWelcome.pack()

    buttonIncome = Button(text="Calculate Income", font = font3, command = numOfIncome)
    buttonIncome.pack()

    buttonOutcome = Button(text="Calculate Outcome", font = font3, command = numOfOutcome)
    buttonOutcome.pack()

    buttonExit = Button(text="Exit", font = font3, command = exit)
    buttonExit.pack()
    
menu()
